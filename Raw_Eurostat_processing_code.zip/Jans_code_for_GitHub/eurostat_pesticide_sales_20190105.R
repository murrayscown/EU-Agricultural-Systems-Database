#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Edited: Murray Scown   **#
#** Date: Jan 2019         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "aei_fm_salpest09"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
#pesticid.sel <- c("I", "F", "H", "Z", "M", "PGR") 
short.label <- "insecticides"
setwd("C:/Users/mu5106sc/Dropbox/STAGS/SDG_data_eurostat/Final_database/SDGs/Goal12/Pesticide_sales/")
###### Settings end ######

# NUTS 2 - SPDF
geodata <- readOGR(dsn='C:/Users/mu5106sc/Dropbox/STAGS/SDG_data_eurostat/Final_database', layer='SDGs_database')
geodata <- geodata[,1:4]

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))

if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) #%>%
sp.data.sub <- sp.data.sub[which(sp.data.sub$pesticid %in% c("F", "H", "I", "M", "PGR", "ZR")),]

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo, pesticid) %>% summarise(pesticides_mean = mean(values,na.rm = TRUE))

## Calculate sum of all pesticides
head(sp.data.sub.mean)
sp.data.sum <- sp.data.sub.mean %>% group_by(geo) %>% summarise(pesticides_sum = sum(pesticides_mean,na.rm = TRUE))

head(sp.data.sum)

# Write to df
write.csv(sp.data.sum, paste(getwd(), "/", "all_pesticide_sales_mean_allnuts.csv", sep=""),row.names=FALSE)




