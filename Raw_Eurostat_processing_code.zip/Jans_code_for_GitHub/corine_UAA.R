library(raster)
library(eurostat)
library(rgdal)
library(sp)

r <- raster("C:/Users/Jan/Documents/g250_clc12_V18_5a/g250_clc12_V18_5.tif")

#r <- crop(r, c(-100000,8048000,-100000,5500000))
r.agg <- aggregate(r, fact=4, fun=modal, na.rm=T)

m <- matrix(c(0, 11, 0,
              11, 21, 1,
              21, Inf, 0), ncol=3, byrow=TRUE)
r.agr <- reclassify(r.agg, m)
r.pixels <- reclassify(r.agg, c(0,200,1))


geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "10")
#geodata <- readRDS("geodata.rds")
geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,] 
#saveRDS(geodata, "geodata.rds")

# Shapefile reprojection
shp.re <- spTransform(geodata.nuts2, crs(r))

sum.crop <- extract(r.agr, shp.re, fun=sum, na.rm=TRUE, sp=TRUE)
sum.total <- extract(r.pixels, shp.re, fun=sum, na.rm=TRUE, sp=TRUE)

sum.crop$agr.rel <- sum.crop$layer / sum.total$layer


