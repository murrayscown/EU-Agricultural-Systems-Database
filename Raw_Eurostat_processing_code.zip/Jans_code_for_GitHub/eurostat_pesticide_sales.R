#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "tai02"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
pesticid.sel <- "I" #insecticides (others: herbicides, fungicides, growth regulators
short.label <- "pesticides"
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Goal12/Pestidice_sales/")
###### Settings end ######

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "10")
#geodata.nuts3 <- geodata[geodata$STAT_LEVL_ == 3,]; names(geodata.nuts3@data)[1] <- "geo"
#geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]; names(geodata.nuts2@data)[1] <- "geo"
#geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,]; 
names(geodata@data)[1] <- "geo"
#geodata <- geodata.cntr

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))

if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) #%>%
  #dplyr::filter(pesticid == pesticid.sel)

## Calculate sum of all pesticides
sp.data.sum <- sp.data.sub %>% group_by(geo, time) %>% summarise(pesticides_sum = sum(values,na.rm = TRUE))

## Calculate mean and median over the years 2010-2017
head(sp.data.sum)
sp.data.sub.mean <- sp.data.sum %>% group_by(geo) %>% summarise(sales_pesticides_mean = mean(pesticides_sum,na.rm = TRUE))
sp.data.sub.median <- sp.data.sum %>% group_by(geo) %>% summarise(sales_pesticides_median = median(pesticides_sum,na.rm = TRUE))

## Rearrange data, years to columns (wide format)
#sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.mean)
head(geodata@data)
#names(geodata@data)[5:ncol(geodata@data)] <-  paste("Y",names(geodata@data)[5:ncol(geodata@data)], sep="")

## Plot map
pdf(paste(short.label, "_mean", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=5:ncol(geodata@data), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


## Weight with UAA data
uaa <- read.csv("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Weights/farmland_ha_allnuts.csv")[,2:3]
uaa$rel <- rep(NA, nrow(uaa)) 
uaa$pesticides.mean <- rep(NA, nrow(uaa)) 
uaa$pesticides.median <- rep(NA, nrow(uaa)) 

for(i in sp.data.sub.mean$geo){
  idx <- grep(paste(i), uaa$geo)
  pest.val <- as.numeric(sp.data.sub.mean[grep(paste(i), sp.data.sub.mean$geo),2])
  uaa$rel[idx] <- uaa[idx,"X2013"] / sum(uaa[idx,"X2013"])
  uaa$pesticides.mean[idx] <- uaa$rel[idx] * pest.val 
}

uaa$rel <- rep(NA, nrow(uaa))
for(i in sp.data.sub.median$geo){
  idx <- grep(paste(i), uaa$geo)
  pest.val <- as.numeric(sp.data.sub.median[grep(paste(i), sp.data.sub.median$geo),2])
  uaa$rel[idx] <- uaa[idx,"X2013"]/ sum(uaa[idx,"X2013"])
  uaa$pesticides.median[idx] <- uaa$rel[idx] * pest.val 
}

uaa <- uaa[,c(1,4,5)]

## Merge attribute data with geodata
#geodata <- geodata.nuts2
geodata@data <- dplyr::left_join(geodata@data, uaa)
head(geodata@data)


## Plot map
pdf(paste(short.label, "_weighted_mean_allnuts", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=7:ncol(geodata), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


## Save data

# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer=paste(short.label), dsn=paste(getwd(), "/", paste(short.label), ".shp", sep=""), driver="ESRI Shapefile")

# Write to df
write.csv(geodata@data[,c(1,7,8)], paste(getwd(), "/", paste(short.label), "_weighted_mean_allnuts", ".csv", sep=""),row.names=FALSE)




