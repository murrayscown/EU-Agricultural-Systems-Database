#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#

# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

###### Settings start ######
var.of.interest <- "tgs00045"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
short.label <- "C21_livestock"
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/CAP_indicators/")
###### Settings end ######

#A2000  Live bovine animals 
#A2300F Milk cows
#A3100  Pigs
#A4100  Sheep
#A4200  Goats

clean_eurostat_cache()

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "10")
names(geodata@data)[1] <- "geo"

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))
if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4)
sp.data.sub <- sp.data.sub[,c(1,3:5)]

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo,animals) %>% summarise(c21_lsu = mean(values,na.rm = TRUE))

## Rearrange data, years to columns (wide format)
sp.data.wide <- recast(sp.data.sub.mean, geo ~ animals, id.var = c("geo", "animals"))

## Merge attribute data with geodata
#geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.wide)
head(geodata@data)

names(geodata)[5:9] <- c("bovine", "milk_cows", "pigs", "sheep", "goats")

## Plot map
pdf(paste(short.label,"_mean_allnuts", ".pdf",sep=""), paper='A4r')
sp::spplot(geodata, zcol=5:ncol(geodata), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()

#for test
#geodata <- geodata[geodata$STAT_LEVL_ == 2,] 

## Save data

# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer='factor_income', dsn=paste(dire, "factor_income.shp", sep=""), driver="ESRI Shapefile")

# Write to df
write.csv(geodata@data[,c(1,5:ncol(geodata))], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)



