#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#

# load packages
library(raster)
library(eurostat)
library(rgdal)
library(sp)
library(viridis)


###### Settings start ######
short.label <- "artificial_share"
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database/SDGs/Goal15/Artifical_area/")
###### Settings end ######

r <- raster("C:/Users/Jan/Documents/g250_clc12_V18_5a/g250_clc12_V18_5.tif")

#r <- crop(r, c(-100000,8048000,-100000,5500000))
r.agg <- aggregate(r, fact=4, fun=modal, na.rm=T)

#select class 23-25 incl
m <- matrix(c(0, 11, 1,
              11, Inf, 0), ncol=3, byrow=TRUE)
r.agr <- reclassify(r.agg, m)
r.pixels <- reclassify(r.agg, c(0,200,1))


# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
geodata <- geodata[geodata$STAT_LEVL_ == 2,]
names(geodata@data)[1] <- "geo"


# Shapefile reprojection
shp.re <- spTransform(geodata, crs(r))

sum.crop <- extract(r.agr, shp.re, fun=sum, na.rm=TRUE, sp=TRUE)
sum.total <- extract(r.pixels, shp.re, fun=sum, na.rm=TRUE, sp=TRUE)

sum.crop$agr.rel <- sum.crop$layer / sum.total$layer

## Plot map
pdf(paste(short.label,"_mean_allnuts", ".pdf",sep=""), paper='A4r')
sp::spplot(sum.crop, zcol=6, main = paste(short.label),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


## Save data

# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer='factor_income', dsn=paste(dire, "factor_income.shp", sep=""), driver="ESRI Shapefile")

# Write to df
names(sum.crop)[1] <- "geo"
write.csv(sum.crop@data[,c(1,6)], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)



