#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "nama_10r_3popgdp"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
#unit.sel <- "MIO_EUR" 
short.label <- "popgdp"
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Weights/")
###### Settings end ######

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "10")
#geodata.nuts3 <- geodata[geodata$STAT_LEVL_ == 3,]; names(geodata.nuts3@data)[1] <- "geo"
#geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]; names(geodata.nuts2@data)[1] <- "geo"
#geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,]; 
names(geodata@data)[1] <- "geo"
#geodata <- geodata.nuts2

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))
if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) == 5) #%>%
  #dplyr::filter(unit == unit.sel)
  
sp.data.sub <- sp.data.sub[,c(2:4)]

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo) %>% summarise(gdppop_mean = mean(values,na.rm = TRUE))
sp.data.sub.median <- sp.data.sub %>% group_by(geo) %>% summarise(gdppop_median = median(values,na.rm = TRUE))

## Rearrange data, years to columns (wide format)
#sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.mean)
head(geodata@data)

## Plot map
pdf(paste(short.label, "_mean", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=5:ncol(geodata@data), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


write.csv(geodata@data[,c(1,5,6)], paste(getwd(), "/", paste(short.label), "_mean", ".csv", sep=""),row.names=FALSE)





