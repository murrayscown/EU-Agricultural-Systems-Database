#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

### Data downloaded from: http://ec.europa.eu/eurostat/statistics-explained/index.php?title=Archive:Agri-environmental_indicator_-_soil_quality
### Data taken from Map 3: Average soil productivity of croplands (expressed in relative terms with indices without measurement units), 2006, EU-27, NUTS 3
#Source: Joint Research Centre, European Commission

sp.data <- read.csv("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Additional_consensus_variables/AEI_26_clean.csv", stringsAsFactors=F)
names(sp.data)[1] <- "geo"
sp.data[,1] <- as.character(sp.data[,1])
sp.data[,2] <- as.numeric(sp.data[,2])


###### Settings start ######
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Additional_consensus_variables/")
short.label <- "soil_quality"
###### Settings end ######

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
names(geodata@data)[1] <- "geo"


## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data)
geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]
head(geodata@data)


## Plot map
pdf(paste(short.label, "_mean", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=5, main = "soil cover",
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()

geodata2 <- geodata[geodata$STAT_LEVL_ == 3,]
geodata2 <- geodata2[,c(1,5)]
lala <- over(geodata.nuts2, geodata2[,2], fn=modal, na.rm=T)
class(lala)
head(lala)

geodata.nuts2$productivity <- lala$cropland.soil.productivity

pdf(paste(short.label, "_mean_allnuts", ".pdf",sep=""), paper='A4')
sp::spplot(geodata.nuts2, zcol=6, main = "soil prod",
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="black", usePolypath = FALSE,
           lwd=0.05)
dev.off()

# Write to df
write.csv(geodata.nuts2@data[,c(1,6)], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)




