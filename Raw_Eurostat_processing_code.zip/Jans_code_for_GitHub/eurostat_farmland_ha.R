#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#

# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "ef_lus_main"
summary(eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE))
time.of.interest <- 2013
crops.sel <- "UAA"
farmtype.sel <- "TOTAL"
unit.sel <- "HA" 
standardoutput <- "TOTAL"
agri.area <- "TOTAL"
var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en")
short.label <- "farmland_ha"
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Weights/")
###### Settings end ######


## Get NUTS data
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "10")
names(geodata@data)[1] <- "geo"
#geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,] #subset to NUTS2
#geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,] #subset to country data
#names(geodata.nuts2@data)[1] <- "geo"
#names(geodata.cntr@data)[1] <- "geo"
#geodata <- geodata.nuts2

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)
unique(sp.data$geo)

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) %>%
  dplyr::filter(crops == paste(crops.sel)) %>% 
  dplyr::filter(farmtype == paste(farmtype.sel)) %>%
  dplyr::filter(unit == paste(unit.sel)) %>%
  dplyr::filter(so_eur == paste(standardoutput)) %>%
  dplyr::filter(agrarea == paste(agri.area)) 
sp.data.sub <- sp.data.sub[,6:8]

## Rearrange data, years to columns (wide format)
head(sp.data.sub)
sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.wide)
names(geodata@data)[5:ncol(geodata@data)] <-  paste("Y",names(geodata@data)[5:ncol(geodata@data)], sep="")

## Plot map
pdf(paste(short.label, "_allnuts.pdf",sep=""), paper='A4r')
sp::spplot(geodata, zcol=5:ncol(geodata@data), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()

## Save data

# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer='factor_income', dsn=paste(dire, "factor_income.shp", sep=""), driver="ESRI Shapefile")

# Write to df
write.csv(sp.data.wide, paste(getwd(), "/", paste(short.label),"_allnuts.csv", sep=""))
#write.csv(sp.data.sub, paste(dire, "factor_income_filtered.csv", sep=""))



