#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#

### Data downloaded from: http://ec.europa.eu/agriculture/cap-indicators/context/2017/c08_en.xlsx
### Table c08_en cleaned and saved as c08_en_clean.csv


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

sp.data <- read.csv("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/SDGs/Goal8/GDP_per_capita/c8_en_clean.csv",stringsAsFactors=F)
names(sp.data)[1] <- "geo"
sp.data[c(13,16,18),2] <- NA

sp.data[,2] <- as.numeric(sp.data[,2])
sp.data[,3] <- as.numeric(sp.data[,3])


###### Settings start ######
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/SDGs/Goal8/GDP_per_capita//")
short.label <- "gdp_capita"
###### Settings end ######

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
names(geodata@data)[1] <- "geo"


## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data)
head(geodata@data)

geodata@data$gdp.rural.rel <- geodata@data$Index.PPS.rural / geodata@data$Index.PPS.total

## Plot map
pdf(paste(short.label, "_mean_allnuts", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=7, main = "gdp_rural.rel",
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


# Write to df
write.csv(geodata@data[,c(1,7)], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)


