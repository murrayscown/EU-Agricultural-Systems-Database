#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Edited: Murray Scown   **#
#** Date: Jan 2019         **#
#****************************#

# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "ef_mporganic"
agrarea.sel <- "TOTAL"
indic_ef.sel <- "A_3_2_3_HA" #Both certified and under conversion
indic_ef.sel.2 <- "AGRAREA_HA" #Utilised agricultural area
var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en")
short.label <- "organic_farming"
setwd("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Goal2/Percentage_organic_farming/")
###### Settings end ######


# NUTS 2 - SPDF
geodata <- readOGR(dsn='C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database', layer='SDGs_database')
#geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,] 
#geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,] 
#names(geodata.nuts2@data)[1] <- "geo"
geodata <- geodata[,1:4]
#names(geodata@data)[1] <- "geo"
#geodata <- geodata.nuts2

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))
if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) %>%
  dplyr::filter(agrarea == paste(agrarea.sel)) %>% 
  dplyr::filter(indic_ef == paste(indic_ef.sel))
sp.data.sub <- sp.data.sub[,3:5]

## Rearrange data, years to columns (wide format)
#sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo) %>% summarise(organic_farms_mean = mean(values,na.rm = TRUE))
sp.data.sub.median <- sp.data.sub %>% group_by(geo) %>% summarise(organic_farms_median = median(values,na.rm = TRUE))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.mean)
head(geodata@data)

## Further processing: Divide by total UAA to get percentage

## Filter data
sp.data.sub.2 <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) %>%
  dplyr::filter(agrarea == paste(agrarea.sel)) %>% 
  dplyr::filter(indic_ef == paste(indic_ef.sel.2))
sp.data.sub.2 <- sp.data.sub.2[,3:5]

## Rearrange data, years to columns (wide format)
#sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Calculate mean and median over the years 2010-2017
head(sp.data.sub.2)
sp.data.sub.mean.2 <- sp.data.sub.2 %>% group_by(geo) %>% summarise(ag_area_mean = mean(values,na.rm = TRUE))
sp.data.sub.median.2 <- sp.data.sub.2 %>% group_by(geo) %>% summarise(ag_area_median = median(values,na.rm = TRUE))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median.2)
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.mean.2)
head(geodata@data)


org.farm <- geodata@data[,c(1,2,6,8)]
org.farm$org_farm <- org.farm$organic_farms_mean / org.farm$ag_area_mean * 100

org.farm[which(org.farm$STAT_LEVL_ == 2 & is.na(org.farm$org_farm)), 'geo']
org.farm[which(org.farm$geo == "EL"),]
org.farm[which(org.farm$geo == "SI"),]
org.farm[which(org.farm$geo == "UK"),]

## Save data
# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer=paste(short.label), dsn=paste(getwd(), "/", paste(short.label), ".shp", sep=""), driver="ESRI Shapefile")

# Write to df
write.csv(org.farm, paste(getwd(), "/", "org_farm", ".csv", sep=""),row.names=FALSE)

