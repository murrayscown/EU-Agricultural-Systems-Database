#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

### Data downloaded from: https://ec.europa.eu/agriculture/cap-indicators/context/2017_en
### Table c36_en cleaned and saved as c36_en_clean.csv

sp.data <- read.csv("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/Data/Goal15/Status_grasslands/c36_en_clean.csv")
names(sp.data)[1] <- "geo"
sp.data[,2:5] <- as.numeric(as.character(unlist(sp.data[,2:5])))

###### Settings start ######
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/Data/Goal15/Status_grasslands/")
short.label <- "grassland_status"
###### Settings end ######

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
geodata.nuts3 <- geodata[geodata$STAT_LEVL_ == 3,]; names(geodata.nuts3@data)[1] <- "geo"
geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]; names(geodata.nuts2@data)[1] <- "geo"
geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,]; names(geodata.cntr@data)[1] <- "geo"
geodata <- geodata.cntr


## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data)
head(geodata@data)


## Plot map
pdf(paste(short.label, "_mean", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=5:8, main = "Grassland status",
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


# Write to df
write.csv(geodata@data[,c(1,5:8)], paste(getwd(), "/", paste(short.label), "_mean", ".csv", sep=""),row.names=FALSE)




