library(raster)
library(eurostat)
library(viridis)

# Data taken from:
# Chaoqun Lu and Hanqin Tian
# Global nitrogen and phosphorus fertilizer use for agriculture production in the past half century: shifted hot spots and nutrient imbalance
# Earth Syst. Sci. Data, 9, 181-192, 2017
# https://www.earth-syst-sci-data.net/9/181/2017/essd-9-181-2017.pdf

setwd("C:/Users/mu5106sc/Dropbox/STAGS/SDG_data_eurostat/Final_database/Additional_consensus_variables/Lu_2017_Nfer_ASCII/")

short.label <- "N_fertilizer_Lu"

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]
names(geodata.nuts2@data)[1] <- "geo"


nfer <- list.files()
nfer <- nfer[110:114]

r <- stack(nfer)
projection(r) <- "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs" 
r <- mean(r)

v <- extract(r, geodata.nuts2, sp=T, fun=mean, na.rm=T)

setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database/Additional_consensus_variables")

pdf(paste(short.label,"_mean_allnuts", ".pdf",sep=""), paper='A4r')
sp::spplot(v, zcol=5, main = "N_fertilizer",
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="black", usePolypath = FALSE,
           lwd=0.05)
dev.off()

# Write to df
write.csv(v@data[,c(1,5)], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)


