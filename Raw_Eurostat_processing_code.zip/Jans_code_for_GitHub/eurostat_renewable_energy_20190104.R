#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Edited: Murray Scown   **#
#** Date: Jan 2019         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "nrg_100a"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
unit.sel <- "KTOE" 
product.sel <- "5500" #renewable energy
indic_nrg.sel <- "B_102030" #agriculture/forestry
short.label <- "renewable_energy"
setwd("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Goal7/Renewable_energy/")
###### Settings end ######

# NUTS 2 - SPDF
geodata <- readOGR(dsn='C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database', layer='SDGs_database')
geodata@data <- geodata@data[,1:4]
#geodata.nuts3 <- geodata[geodata$STAT_LEVL_ == 3,]; names(geodata.nuts3@data)[1] <- "geo"
#geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]; names(geodata.nuts2@data)[1] <- "geo"
#geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,]; 
#names(geodata@data)[1] <- "geo"
#geodata <- geodata.cntr

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))
if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) %>%
  dplyr::filter(unit == unit.sel, product == product.sel, indic_nrg == indic_nrg.sel)
  
sp.data.sub <- sp.data.sub[,c(4:6)]

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo) %>% summarise(renewable_energy_mean = mean(values,na.rm = TRUE))
sp.data.sub.median <- sp.data.sub %>% group_by(geo) %>% summarise(renewable_energy_median = median(values,na.rm = TRUE))

## Rearrange data, years to columns (wide format)
#sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.mean)
head(geodata@data)

## Weight with UAA und forest data
uaa <- read.csv("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Weights/farmland_ha_allnuts.csv")[,2:3]
forest <- read.csv("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Weights/forest_sqkm_mean_allnuts.csv")[,c(1,3)] #only mean
forest$forest_mean <- forest$forest_mean * 100 #convert to ha

uaa <- dplyr::left_join(uaa, forest)
names(uaa)[2] <- "uaa"
uaa <- na.omit(uaa)

#NUTS0 uaa and energy
nuts0 <- inner_join(sp.data.sub.mean, uaa[,1:3])
head(nuts0)
nuts0$ag_ren_energy <- nuts0$renewable_energy_mean * (nuts0$uaa / rowSums(nuts0[,3:4]))
nuts0$ren_energy_rt <- 1000 * nuts0$ag_ren_energy / nuts0$uaa #Units toe/ha
head(nuts0)


## Merge with total energy use in ag and forestry
energy <- read.csv("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Goal7/Energy_use/energy_rate_in_ag_20190104.csv")
head(energy)

ren.energy <- left_join(energy[,c(1,3)], nuts0[,c(1,5)])
ren.energy$ren_nrg_pct <- ren.energy[,3] / ren.energy[,2] * 100
head(ren.energy)  

# Write to df
write.csv(ren.energy, "ren_energy_pct_in_ag_20190104.csv",row.names=FALSE)




