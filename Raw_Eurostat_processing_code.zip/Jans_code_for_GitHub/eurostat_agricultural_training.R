#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#

# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

###### Settings start ######
#var.of.interest <- "agr_r_accts"
#agr.indic <- "PROD_BP"
#list.of.prod <- 26000
#unit.of.interest <- "MIO_EUR" 
#var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en")
short.label <- "agr_training_below_35"
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database/SDGs/Goal4/Agricultural_training")
###### Settings end ######

clean_eurostat_cache()

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "10")
names(geodata@data)[1] <- "geo"

## Read CSV attribute data
sp.data.2005 <- read.csv <- read.csv("TRAINMAN_NUTS_2005_CSV.csv")
names(sp.data.2005)[4] <- "geo"
sp.data.2010 <- read.csv("TRAINMAN_NUTS_2010_CSV.csv")
names(sp.data.2010)[4] <- "geo"
sp.data.2013 <- read.csv("TRAINMAN_NUTS_2013_CSV.csv")
names(sp.data.2013)[4] <- "geo"

sp.ts <- rbind(sp.data.2010, sp.data.2005, sp.data.2013)

## Filter data
sp.total <- sp.ts %>%
  dplyr::filter(EB_TRAINING.1 == "Total", EB_AGEMANAGER.1 == "[0001] Y_LT35", EB_SEXMANAGER.1 == "Total") 

sp.basic <- sp.ts %>%
  dplyr::filter(EB_TRAINING.1 == "[0001] Basic", EB_AGEMANAGER.1 == "[0001] Y_LT35", EB_SEXMANAGER.1 == "Total") 

sp.full <- sp.ts %>%
  dplyr::filter(EB_TRAINING.1 == "[0003] Full", EB_AGEMANAGER.1 == "[0001] Y_LT35", EB_SEXMANAGER.1 == "Total") 


sp.total <- sp.total[,c(1,4,14)]; sp.basic <- sp.basic[,c(1,4,14)]; sp.full <- sp.full[,c(1,4,14)]
names(sp.total)[3] <- "values"; names(sp.basic)[3] <- "values"; names(sp.full)[3] <- "values"

## Calculate mean and median over the years
sp.total.mean <- sp.total %>% group_by(geo) %>% summarise(training_total_mean = mean(values,na.rm = TRUE))
sp.total.median <- sp.total %>% group_by(geo) %>% summarise(training_total_median = median(values,na.rm = TRUE))

sp.basic.mean <- sp.basic %>% group_by(geo) %>% summarise(training_basic_mean = mean(values,na.rm = TRUE))
sp.basic.median <- sp.basic %>% group_by(geo) %>% summarise(training_basic_median = median(values,na.rm = TRUE))

sp.full.mean <- sp.full %>% group_by(geo) %>% summarise(training_full_mean = mean(values,na.rm = TRUE))
sp.full.median <- sp.full %>% group_by(geo) %>% summarise(training_full_median = median(values,na.rm = TRUE))

# Combine
sp.comb.mean <- dplyr::left_join(sp.total.mean, sp.basic.mean)
sp.comb.mean <- dplyr::left_join(sp.comb.mean, sp.full.mean)

# Calculate rations
head(sp.comb.mean)
sp.comb.mean$prop.basic <- sp.comb.mean$training_basic_mean / sp.comb.mean$training_total_mean
sp.comb.mean$prop.full <- sp.comb.mean$training_full_mean / sp.comb.mean$training_total_mean

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.comb.mean)
#geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
head(geodata@data)

## Plot map
pdf(paste(short.label,"_mean_allnuts", ".pdf",sep=""), paper='A4r')
sp::spplot(geodata, zcol=8:9, main = paste(short.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()

## Save data

# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer='factor_income', dsn=paste(dire, "factor_income.shp", sep=""), driver="ESRI Shapefile")

# Write to df
write.csv(geodata@data[,c(1,8,9)], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)



