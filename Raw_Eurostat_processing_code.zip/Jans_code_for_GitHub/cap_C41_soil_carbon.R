#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Date: May 2018         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

### Data downloaded from: https://ec.europa.eu/agriculture/cap-indicators/context/2017_en
### Table c41_en cleaned and saved as c41_en_clean.csv

sp.data <- read.csv("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Additional_consensus_variables/c41_en_clean.csv", stringsAsFactors = F)
names(sp.data)[1] <- "geo"
sp.data[5,2] <- "1335.8"
sp.data[10,2] <- "2134"
sp.data[28,2] <- "2151.4"
sp.data[,2] <- as.numeric(sp.data[,2])
#sp.data[11,2] <- NA

###### Settings start ######
setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Additional_consensus_variables/")
short.label <- "C41_soil_carbon"
###### Settings end ######

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
names(geodata@data)[1] <- "geo"


## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data)
head(geodata@data)


## Plot map
pdf(paste(short.label, "_mean_allnuts", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=5, main = "soil_carbon",
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


# Write to df
write.csv(geodata@data[,c(1,5)], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)




