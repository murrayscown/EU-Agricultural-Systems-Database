# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)
library(arcgisbinding)

### 1 SDGS ### -------------------------------------------------------------------------------------

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
names(geodata@data)[1] <- "geo"

setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database/SDGs/")

sdg.list <- list.files(pattern = "mean_allnuts.csv$" , recursive = TRUE)
idx.weights <- grep(sdg.list, pattern="Weights")
sdg.list <- sdg.list[-idx.weights]
list.names <- gsub(".*/","", sdg.list)
list.names <- gsub("_mean_allnuts.*","", list.names)

sdg.list <- sdg.list[-2]
myfiles <- lapply(sdg.list, read.csv)
unique(sapply(myfiles, FUN=nrow))

for (i in 1:length(myfiles)){
  # Merge attribute data with geodata
  geodata@data <- dplyr::left_join(geodata@data, myfiles[[i]])
  
}
merged <- geodata

#remove median
idx.median <- grep("median", names(merged))
merged <- merged[,-idx.median]

#clean and fix names
merged <- merged[, names(merged) != "X"]
names(merged) <- gsub("\\.", "_", names(merged))

#test 
sp::spplot(merged, zcol=19,
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)

#arc.write(path="C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/SDGs/SDGs.shp", data = merged)

#reorder
head(merged@data)
names(merged)
merged <- merged[,c(1:4,5,12,13,14:17,20:22,18:19,23:24,26,28,25,27,6,10,7,11,8:9)]

# Write to shapefile
names(merged)
new.names <- c("geo","STAT_LEVL_","SHAPE_AREA","SHAPE_LEN","risk_pov","factor_in","org_farm","train35bas","train35ful","train_bas",
               "train_ful","nitr_high","nitr_mod","nitr_poor","irrigated","irrig_vol","energy","ren_energy",
               "gdp_rural","unemp_yout","unemp_rate","unemp_long","pesticides","forest","artific","soil_loss",
               "com_birds","farm_birds"
)
names(merged) <- new.names

merged <- merged[merged$STAT_LEVL_ <= 2,]

writeOGR(merged, layer = "SDGs_database", dsn="C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database", driver="ESRI Shapefile", overwrite_layer=T)



### 2 Additional Consensus Variables ### -------------------------------------------------------------------------------------

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
names(geodata@data)[1] <- "geo"

setwd("C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database/Additional_consensus_variables/")

var.list <- list.files(pattern = "mean_allnuts.csv$" , recursive = TRUE)
list.names <- gsub(".*/","", sdg.list)
list.names <- gsub("_mean_allnuts.*","", list.names)

myfiles <- lapply(var.list, read.csv)
unique(sapply(myfiles, FUN=nrow))

#merge
#merged <- do.call(cbind,myfiles)
for (i in 1:length(myfiles)){
  # Merge attribute data with geodata
  geodata@data <- dplyr::left_join(geodata@data, myfiles[[i]])
  
}
merged <- geodata

#remove median
#idx.median <- grep("median", names(merged))
#merged <- merged[,-idx.median]

#clean and fix names
#merged <- merged[, names(merged) != "X"]
names(merged) <- gsub("\\.", "_", names(merged))


merged <- merged[merged$STAT_LEVL_ <= 2,]

#test 
sp::spplot(merged, zcol=41,
           col.regions = viridis(100),
           col="black", usePolypath = FALSE,
           lwd=0.05)


#reorder
head(merged@data)
names(merged)
merged <- merged[,c(1:4,5:9,10:12,42,14:16,
                    25:35,19:23,17,24,13,36:41,18)]

# Write to shapefile
names(merged)
new.names <- c("geo","STAT_LEVL_","SHAPE_AREA","SHAPE_LEN","total","wintercrop","cover_crop","plant_res","bare_soil","conv_till","cons_till",
               "zero_till","nfert","arable","grassland","permanent","wheat_a","rye_a","barley_a","oats_A","crnmaize_a","fruits_a","grmaize_a","olives_a",
               "citrus_a","vegetab_a","wine_a","bovine","milk_cows","pigs","sheep","goats","org_carbon","labour_for","soil_prod","wheat_y",
               "rye_y","barley_y","oat_y","maize_y","grmaize_y","lab_prod")

names(merged) <- new.names

writeOGR(merged, layer = "Add_con_vars_database", dsn="C:/Users/Jan/Dropbox/Projektassistent_LUCSUS/SDG_data_eurostat/Final_database", driver="ESRI Shapefile")







