#** Download EUROSTAT data **#
#** Author: Jan Blanke     **#
#** Edited: Murray Scown   **#
#** Date: Jan 2019         **#
#****************************#


# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

clean_eurostat_cache()

###### Settings start ######
var.of.interest <- "nrg_100a"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
unit.sel <- "KTOE" 
product.sel <- "0000" #all products
indic_nrg.sel <- "B_102030" #agriculture/forestry
short.label <- "energy_use"
setwd("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Goal7/Energy_use/")
###### Settings end ######

# NUTS 2 - SPDF
geodata <- readOGR(dsn='C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database', layer='SDGs_database')
geodata@data <- geodata@data[,1:4]
#geodata.nuts3 <- geodata[geodata$STAT_LEVL_ == 3,]; names(geodata.nuts3@data)[1] <- "geo"
#geodata.nuts2 <- geodata[geodata$STAT_LEVL_ == 2,]; names(geodata.nuts2@data)[1] <- "geo"
#geodata.cntr <- geodata[geodata$STAT_LEVL_ == 0,]; 
#names(geodata@data)[1] <- "geo"
#geodata <- geodata.cntr

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))
if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4) %>%
  dplyr::filter(unit == unit.sel, product == product.sel, indic_nrg == indic_nrg.sel)
  
sp.data.sub <- sp.data.sub[,c(4:6)]

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo) %>% summarise(energy_use_mean = mean(values,na.rm = TRUE))
sp.data.sub.median <- sp.data.sub %>% group_by(geo) %>% summarise(energy_use_median = median(values,na.rm = TRUE))

## Rearrange data, years to columns (wide format)
#sp.data.wide <- recast(sp.data.sub, geo ~ time, id.var = c("geo", "time"))

## Merge attribute data with geodata
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.mean)
head(geodata@data)

## Plot map
pdf(paste(short.label, "_mean", ".pdf",sep=""), paper='A4')
sp::spplot(geodata, zcol=5:ncol(geodata@data), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()


## Weight with UAA und forest data
uaa <- read.csv("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Weights/farmland_ha_allnuts.csv")[,2:3]
forest <- read.csv("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/SDGs/Weights/forest_sqkm_mean_allnuts.csv")[,c(1,3)] #only mean
forest$forest_mean <- forest$forest_mean * 100 #convert to ha

uaa <- dplyr::left_join(uaa, forest)
names(uaa)[2] <- "uaa"
uaa <- na.omit(uaa)

uaa$rel <- rep(NA, nrow(uaa)) 
uaa$energy.mean <- rep(NA, nrow(uaa)) 
uaa$energy.median <- rep(NA, nrow(uaa)) 

#NUTS0 uaa and energy
nuts0 <- inner_join(sp.data.sub.mean, uaa[,1:3])
head(nuts0)
nuts0$ag_energy <- nuts0$energy_use_mean * (nuts0$uaa / rowSums(nuts0[,3:4]))
nuts0$energy_rt <- 1000 * nuts0$ag_energy / nuts0$uaa #Units toe/ha
head(nuts0)


# Write to df
write.csv(nuts0[,c(1,2,5,6)], "energy_rate_in_ag_20190104.csv",row.names=FALSE)




