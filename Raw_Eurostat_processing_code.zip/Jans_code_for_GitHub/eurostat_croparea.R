#** Download EUROSTAT data *********************#
#** Author: Jan Blanke edited by Murray Scown **#
#** Date: May 2018 edited Dec 2018 *************#
#***********************************************#

# load packages
library(eurostat)
library(sp)
library(dplyr)
library(viridis)
library(reshape)
library(rgdal)

###### Settings start ######
var.of.interest <- "apro_cpnhr"

## Download attribute data from Eurostat
sp.data <- eurostat::get_eurostat(paste(var.of.interest), time_format = "raw", stringsAsFactors = FALSE)
# First start with data where NUTS2 are available (crops excluding fruits and fresh vegetables)
crops.sel <- c("C1110",
               "C1120",
               "C1200", 
               "C1300", 
               "C1410", 
               "C1420", 
               "C1500",
               "C1600",
               "C1700",
               "C1800",
               "C1900",
               "C2000",
               "P0000",
               "R1000",
               "R2000",
               "R9000",
               "P0000",
               "I1110",
               "I1120",
               "I1130",
               "I1140",
               "I1150",
               "I1190",
               "I2100",
               "I2200",
               "I2300",
               "I2900",
               "I3000",
               "I4000",
               "I5000",
               "I6000",
               "I9000",
               "G1000", 
               "G2000", 
               "G3000", 
               "G9100", 
               "G9900")
strucpro.sel <- "AR"
(var.label <- label_eurostat_tables(paste(var.of.interest), lang = "en"))
short.label <- "croparea"
setwd("C:/Users/mu5106sc/Dropbox/SDG_data_eurostat/Final_database/Crop_area_yield/")
###### Settings end ######

clean_eurostat_cache()

# NUTS 2 - SPDF
geodata <- get_eurostat_geospatial(output_class = "spdf", resolution = "60")
#names(geodata@data)[1] <- "geo"

## Get time series to be used
year.cnt.2010 <- length(which(as.numeric(unique(sp.data$time))>= 2010))
if (year.cnt.2010 >= 5){
  time.of.interest <- 2010:2017 # if at least 5 years of data exist after 2010
} else {
  time.of.interest <- sort(as.numeric(unique(sp.data$time)), decreasing=T)[1:5]
  time.of.interest <- sort(na.omit(time.of.interest))
}

## Filter data
sp.data.sub <- sp.data %>%
  dplyr::filter(crops %in% paste(crops.sel)) %>%
  dplyr::filter(time >= min(time.of.interest) & time <= max(time.of.interest), nchar(geo) <= 4, 
                strucpro == paste(strucpro.sel)) 
sp.data.sub <- sp.data.sub[,c(1,3:5)]

## Calculate mean and median over the years 2010-2017
head(sp.data.sub)
sp.data.sub.mean <- sp.data.sub %>% group_by(geo, crops) %>% summarise(yield = mean(values,na.rm = TRUE))

## Rearrange data, years to columns (wide format)
sp.data.wide <- recast(sp.data.sub.mean, geo ~ crops, id.var = c("geo", "crops"))

## Calculate necessary sums (see documentation)
names(sp.data.wide)
sp.data.wide.sum <- sp.data.wide[,c(1,4,5,8:13,18,19,33:36)]
names(sp.data.wide.sum)
names(sp.data.wide.sum) <- c("geo",
                             "rye_a",
                             "barley_a",
                             "maize_a",
                             "tritic_a",
                             "sorghum_a",
                             "oth_cer_a",
                             "rice_a",
                             "pasture_a",
                             "rape_a",
                             "sunflow_a",
                             "pulses_a",
                             "potato_a",
                             "sugbeet_a",
                             "oth_rt_a"
                             )

sp.data.wide.sum$wheat_a <- sp.data.wide$C1110 + 
                            sp.data.wide$C1120

sp.data.wide.sum$oats_a <- sp.data.wide$C1410 + 
                           sp.data.wide$C1420

sp.data.wide.sum$oth_oil_a <- 
  sp.data.wide$I1130 + 
  sp.data.wide$I1140 + 
  sp.data.wide$I1150 + 
  sp.data.wide$I1190 

sp.data.wide.sum$fibre_a <- 
  sp.data.wide$I2100 + 
  sp.data.wide$I2200 + 
  sp.data.wide$I2300 + 
  sp.data.wide$I2900 

sp.data.wide.sum$oth_ind_a <- 
  sp.data.wide$I3000 + 
  sp.data.wide$I4000 + 
  sp.data.wide$I5000 + 
  sp.data.wide$I6000 + 
  sp.data.wide$I9000 
  
sp.data.wide.sum$fodder_a <- 
  sp.data.wide$G2000 + 
  sp.data.wide$G3000 + 
  sp.data.wide$G9100 + 
  sp.data.wide$G9900

summary(sp.data.wide.sum)

## Merge attribute data with geodata
#geodata@data <- dplyr::left_join(geodata@data, sp.data.sub.median)
geodata@data <- dplyr::left_join(geodata@data, sp.data.wide.sum)
head(geodata@data)

## Plot map
pdf(paste(short.label,"_mean_allnuts", ".pdf",sep=""), paper='A4r')
sp::spplot(geodata, zcol=5:ncol(geodata), main = paste(var.label),
           xlim = c(-22,34), ylim = c(35,70),
           col.regions = viridis(100),
           col="transparent", usePolypath = FALSE,
           lwd=0.05)
dev.off()

#for test
#geodata <- geodata[geodata$STAT_LEVL_ == 2,] 

## Save data

# Write to shapefile
#geodata@data[,5:ncol(geodata@data)][is.na(geodata@data[,5:ncol(geodata@data)])] <- -9999
#writeOGR(geodata, layer='factor_income', dsn=paste(dire, "factor_income.shp", sep=""), driver="ESRI Shapefile")
names(geodata@data)[5:ncol(geodata)] <- c("weizen_a", "rye_a", "barley_a", "oats_A", "cornmaize_a","fruits_a", 
                                          "silomaize_a", "olives_a", "zitrus_a", "vegetables_a", "wine_a")


# Write to df
write.csv(geodata@data[,c(1,5:ncol(geodata))], paste(getwd(), "/", paste(short.label), "_mean_allnuts", ".csv", sep=""),row.names=FALSE)



